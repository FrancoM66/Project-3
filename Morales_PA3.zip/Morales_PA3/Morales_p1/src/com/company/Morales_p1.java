package com.company;

import java.security.SecureRandom;
import java.util.Scanner;

public class Morales_p1 {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int i;
        double grade, userIn;

        boolean Ro = true;

        while(Ro) {

            double counter = 0;
            int stiffness = difficulty();
            int Thanos = operator();
            for (i = 0; i <= 10; i++) {
                double correct = getRand(stiffness, Thanos);
                userIn = scan.nextDouble();

                if (userIn == correct) {
                    System.out.println(rightAnswer());
                    counter++;
                } else {
                    System.out.println(wrongAnswer());
                }



            }
            grade = (counter / 10) * 100;
            System.out.println("Your grade is \n" + grade);

            if (grade < 75.0)
            {
                System.out.println("Please ask your teacher for extra help.\n");
            }
            else
                {
                System.out.println("Congratulations, you are ready to go to the next level!\n");
                }

            System.out.println("Do you wish to continue?\n");
            System.out.println("1 for yes / 2 for no");
            int loop;

            loop = scan.nextInt();
            if (loop == 1)
            {
                Ro = true;
            }
            else
            {
                Ro = false;
            }
        }


    }

    static int getRand(int stiffness, int Thanos)
    {
        //Object SecureRandom
        SecureRandom randy = new SecureRandom();
        Scanner scan = new Scanner(System.in);

        int gen1 = 0, gen2 = 0, answer = 0;
        int max,max1,max2,max3;
        int min,min1,min2,min3;

        max = 9;
        min = 1;

        max1 = 99;
        min1 = 10;

        max2 = 999;
        min2 = 100;

        max3 = 9999;
        min3 = 1000;

        char question;
        int questionGetter;

        if(stiffness == 1)
        {
            gen1 = randy.nextInt((max-min+1)+min);
            gen2 = randy.nextInt((max-min+1)+min);
        }
        else if(stiffness == 2)
        {
            gen1 = randy.nextInt((max1-min1+1)+min1);
            gen2 = randy.nextInt((max1-min1+1)+min1);
        }
        else if(stiffness == 3)
        {
            gen1 = randy.nextInt((max2-min2+1)+min2);
            gen2 = randy.nextInt((max2-min2+1)+min2);
        }
        else if(stiffness == 4)
        {
            gen1 = randy.nextInt((max3-min3+1)+min3);
            gen2 = randy.nextInt((max3-min3+1)+min3);
        }

        else
        {
            System.out.println("Wrong choice");
        }

        if(Thanos == 1)
        {
            question = '+';
            System.out.println("How much is " + gen1 + " plus " +  gen2);
            answer = gen1 + gen2;

        }
        else if(Thanos == 2)
        {
            question = '*';
            System.out.println("How much is " + gen1 + " times " +  gen2);
            answer = gen1 * gen2;
        }
        else if(Thanos == 3)
        {
            question = '-';
            System.out.println("How much is " + gen1 + " minus " +  gen2);
            answer = gen1 - gen2;
        }
        else if(Thanos == 4)
        {
            question = '/';
            System.out.println("How much is " + gen1 + " divided by " +  gen2);
            System.out.println("Please round down to the nearest whole number :)");
            answer = gen1 / gen2;
            answer = Math.round(answer*100)/100;
        }
        else if (Thanos == 5)
        {
            questionGetter = randy.nextInt(4 + 1);

            if(questionGetter == 1)
            {
                question = '+';
                System.out.println("How much is " + gen1 + " plus " +  gen2);
                answer = gen1 + gen2;

            }
            else if(questionGetter == 2)
            {
                question = '*';
                System.out.println("How much is " + gen1 + " times " +  gen2);
                answer = gen1 * gen2;
            }
            else if(questionGetter == 3)
            {
                question = '-';
                System.out.println("How much is " + gen1 + " minus " +  gen2);
                answer = gen1 - gen2;
            }
            else if(questionGetter == 4)
            {

                question = '/';
                System.out.println("How much is " + gen1 + " divided by " +  gen2);
                System.out.println("Please round down to the nearest whole number :)");
                answer = gen1 / gen2;
                answer = Math.round(answer*100)/100;
            }

        }


        return answer;
    }


    static String rightAnswer()
    {
        SecureRandom randy2 = new SecureRandom();
        int spin = randy2.nextInt(4) + 1;
        String response;

        switch (spin)
        {
            case 1:
                response = "Very good!\n";
                break;
            case 2:
                response = "Excellent!\n";
                break;
            case 3:
                response = "Nice work!\n";
                break;
            case 4:
                response = "Keep up the good work!\n";
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + spin);
        }
        return response;


    }
    static String wrongAnswer()
    {
        SecureRandom randy3 = new SecureRandom();
        int spin = randy3.nextInt(4) + 1;
        String response;

        switch (spin)
        {
            case 1:
                response = "No. Please try again.\n";
                break;
            case 2:
                response = "Wrong. Try once more.\n";
                break;
            case 3:
                response = "Don’t give up!\n";
                break;
            case 4:
                response = "No. Keep trying.\n";
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + spin);
        }
        return response;


    }

    static int difficulty()
    {
        Scanner dif = new Scanner(System.in);
        int choice;

        System.out.println("Difficulty levels");
        System.out.println("1 = KinderGarden");
        System.out.println("Level one consists of single digit numbers\n");
        System.out.println("2 = Wow ur so good");
        System.out.println("Level two consists of double digit numbers\n");
        System.out.println("3 = Oof");
        System.out.println("Level three consists of triple digit numbers\n");
        System.out.println("4 = Good Luck ;)");
        System.out.println("Level four consists of quadruple digit numbers\n");

        choice = dif.nextInt();
        return choice;

    }

    static int operator()
    {
        Scanner op = new Scanner(System.in);
        int SmoothOperator;

        System.out.println("Please choose an operator");
        System.out.println("1 = +");
        System.out.println("2 = *");
        System.out.println("3 = -");
        System.out.println("4 = /");
        System.out.println("5 = Combination of 4 above");

        SmoothOperator = op.nextInt();

        return SmoothOperator;

    }
}

