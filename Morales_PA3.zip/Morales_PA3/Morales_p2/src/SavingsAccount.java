public class SavingsAccount {
    static private double annualInterestRate;
    private double savingBalance;

    public SavingsAccount()
    {

    }


    //Constructor method
    public SavingsAccount(double savingBalance)
    {
        this.savingBalance = savingBalance;
    }

    public void calculateMonthlyInterest()
    {
        double monthlyI;
        monthlyI = this.savingBalance * annualInterestRate / 12;
        this.savingBalance += monthlyI;
    }



    public double getSavingBalance()
    {
        return this.savingBalance;
    }


    public static void modifyInterestRate(double newInterestRate)
    {
        annualInterestRate = newInterestRate;
    }



}
